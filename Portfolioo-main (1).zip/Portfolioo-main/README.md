<img  alt="portfolio" width="100%" src="https://miro.medium.com/v2/resize:fit:1400/0*s7-847-cMWNrfnyH.gif">
<h1 align="center">Hi 👋, I'm Lanka Divya Lakshmi Bharathi</h1>
<h3 align="center">A passionate Web developer from India</h3>

- 🔭 Education Update  **Recent Gradute**

- 🌱 I’m currently learning **Full Stack Development**

- 👨‍💻 My portfolio website [https://divyalanka2003.github.io/Portfolio/]

- 💬 Ask me about **Python, HTML, CSS, SQL**

- 📫 How to reach me **divyalanka2003@gmail.com**

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://www.linkedin.com/in/lanka-divya-lakshmi-bharathi-123398246" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="midhun-v-s" height="30" width="40" /></a>
<a href="https://www.instagram.com/_divya_lanka_" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="midhun_021" height="30" width="40" /></a>
</p>



